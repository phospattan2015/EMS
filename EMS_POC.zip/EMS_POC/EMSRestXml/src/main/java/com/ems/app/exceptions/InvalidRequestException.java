package com.ems.app.exceptions;

public class InvalidRequestException extends Exception {

	private static final long serialVersionUID = -2400362718749979067L;
	
	private String errorDescription;
	
	public InvalidRequestException(String errorDescription){
		super(errorDescription);
		this.errorDescription =errorDescription;
		
	}

	public InvalidRequestException(String errorDescription, Exception e){
		super(errorDescription, e);
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

}
