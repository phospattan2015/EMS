package com.ems.app.service;

import java.io.IOException;

import javax.xml.bind.JAXBException;

import org.xml.sax.SAXException;

import com.ems.app.entity.EmployeeEntity;
import com.ems.app.exceptions.InvalidRequestException;
import com.ems.app.xsd.Employee;

public interface EmployeeService {
	public boolean saveEmployee(Employee employee) throws JAXBException, SAXException, IOException, InvalidRequestException;
	public boolean updateEmployee(Employee employee) throws JAXBException, SAXException, IOException, InvalidRequestException;
}
