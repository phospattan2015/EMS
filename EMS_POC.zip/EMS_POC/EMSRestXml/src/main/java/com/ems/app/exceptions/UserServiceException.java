package com.ems.app.exceptions;

public class UserServiceException extends Exception{

	private static final long serialVersionUID = -1579827316404833651L;

	public UserServiceException(){
		
	}
	
	public  UserServiceException(String errorDescription, Exception exception){
		super(errorDescription,exception);
	}
}
