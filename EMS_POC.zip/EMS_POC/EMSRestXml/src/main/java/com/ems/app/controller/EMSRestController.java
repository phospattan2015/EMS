package com.ems.app.controller;

import java.io.IOException;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.xml.sax.SAXException;

import com.ems.app.entity.ErrorCode;
import com.ems.app.exceptions.InvalidRequestException;
import com.ems.app.exceptions.UserServiceException;
import com.ems.app.service.EmployeeService;
import com.ems.app.service.ErrorCodeService;
import com.ems.app.util.ErrorCodeConstants;
import com.ems.app.xsd.Employee;

@RestController
public class EMSRestController {
	private static final Logger logger = LoggerFactory.getLogger(EMSRestController.class);
	private static final String BAD_REQUEST = "400";
	
	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private ErrorCodeService errorCodeService;
	
	@RequestMapping("/")
	String home() {
		return "EMS Home Page!";
	}
	
	/**
	 * Rest service to save the Employee Information.
	 * @param employee
	 * @return
	 * @throws UserServiceException 
	 */
	@PostMapping(path="/saveempinfo", consumes = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<String> saveEmployeeInfo(@RequestBody Employee employee) throws UserServiceException{
		logger.debug("###### Begin saveEmployeeInfo  ######\n");
		String empSavedResult="";
		long overAllSaveStartTime = System.currentTimeMillis(); 
		try{
			long startTime = System.currentTimeMillis(); 
			employeeService.saveEmployee(employee);
			long end = System.currentTimeMillis(); 
			long timeElaspe =end - startTime; 
	  	    logger.debug("Employee Saved Successfully in "+timeElaspe+" milli seconds");
		}catch(JAXBException  | SAXException | IOException xsdValException){
			errorCodeService.insertError(new ErrorCode(ErrorCodeConstants.ERROR_CODE_1001, ErrorCodeConstants.INVALID_XML_INPUT));
			logger.error(xsdValException.getMessage());
			empSavedResult = "User Create :: Invalid input XML"+xsdValException.getMessage();
			throw new UserServiceException(empSavedResult,xsdValException);
		}catch(InvalidRequestException invalidRequestException){
			errorCodeService.insertError(new ErrorCode(ErrorCodeConstants.ERROR_CODE_1002, ErrorCodeConstants.INVALID_XML_INPUT));
			logger.error(invalidRequestException.getMessage());
			empSavedResult = "User Update :: Invalid input XML in last 24 hours "+invalidRequestException.getMessage();
			throw new UserServiceException(empSavedResult,invalidRequestException);
		}catch(Exception e){
			logger.error("JPA create user exception : "+e.getMessage());
			errorCodeService.insertError(new ErrorCode(ErrorCodeConstants.ERROR_CODE_2001, ErrorCodeConstants.JPA_CREATE_USER_ERRROR));
			empSavedResult = "User Create :: Exception while saving the user :"+e.getMessage();
			throw new UserServiceException(empSavedResult,e);
			//return  createCustomHeaderResponse(empSavedResult, BAD_REQUEST,e);
		}  
		long overAllSaveEndTime = System.currentTimeMillis(); 
		long overAllSaveTimeElaspsed = overAllSaveEndTime - overAllSaveStartTime;
		logger.debug("Total Time taken to process save request in milli seconds :"+overAllSaveTimeElaspsed);		
		empSavedResult = " Employee information saved successfull :: in :: "+ overAllSaveTimeElaspsed+" milli seconds";
		logger.debug("###### End saveEmployeeInfo  ######\n");
		return createCustomHeaderResponse(empSavedResult);
	}	 
	
	/**
	 * Rest service to update the Employee Information
	 * @param id
	 * @param employee
	 * @return - result
	 * @throws UserServiceException 
	 */
	@RequestMapping(value="/empdata/{id}", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_XML_VALUE)
	public ResponseEntity<String> updateEmployeeInfo(@PathVariable(value = "id") String id, @RequestBody Employee employee) throws UserServiceException {
		logger.debug("###### Begin updateEmployeeInfo  ######\n");
		String empUpdatedResult ="";
		long overAllUpdStartTime = System.currentTimeMillis(); 
		logger.debug(" putData  Id:"+ id);
		logger.debug(" putData  Emp Nme:"+ employee.getName());
		/*  Service call logic here. */
		try{
			long updateStartTime = System.currentTimeMillis(); 
			employee.setId(id);
			employeeService.updateEmployee(employee);
			long updateEndTime = System.currentTimeMillis(); 
			long timeElaspe = updateEndTime - updateStartTime; 
	  	    logger.debug("Employee Saved Successfully in "+timeElaspe+" milli seconds");
		}catch(JAXBException  | SAXException | IOException xsdValException){
			errorCodeService.insertError(new ErrorCode(ErrorCodeConstants.ERROR_CODE_1001, ErrorCodeConstants.INVALID_XML_INPUT));
			logger.error(xsdValException.getMessage());
			empUpdatedResult = "User Update :: Invalid input XML"+xsdValException.getMessage();
			throw new UserServiceException(empUpdatedResult,xsdValException);
			//return  createCustomHeaderResponse(empUpdatedResult, BAD_REQUEST,xsdValException);
		}catch(InvalidRequestException invalidRequestException){
			errorCodeService.insertError(new ErrorCode(ErrorCodeConstants.ERROR_CODE_1002, ErrorCodeConstants.INVALID_XML_INPUT));
			logger.error(invalidRequestException.getMessage());
			empUpdatedResult = "User Update :: Invalid input XML in last 24 hours "+invalidRequestException.getMessage();
			throw new UserServiceException(empUpdatedResult,invalidRequestException);
		}catch(Exception e){
			logger.error("Exception occured while updating the user  : "+e.getMessage());
			errorCodeService.insertError(new ErrorCode(ErrorCodeConstants.ERROR_CODE_2001, ErrorCodeConstants.JPA_CREATE_USER_ERRROR));
			empUpdatedResult = "Exception occured while updating the user  : "+e.getMessage();
			throw new UserServiceException(empUpdatedResult,e);
			//return  createCustomHeaderResponse(empUpdatedResult, BAD_REQUEST,e);
		}  
		long overAllUpdEndTime = System.currentTimeMillis(); 
		long overAllUpdTimeElaspsed = overAllUpdEndTime-overAllUpdStartTime;
		logger.debug("Total Time taken to process save request in milli seconds :"+overAllUpdTimeElaspsed);		
		empUpdatedResult = " Employee information updated successfull :: in :: "+ overAllUpdTimeElaspsed +" milli seconds";
		logger.debug("###### End updateEmployeeInfo  ######\n");
		return createCustomHeaderResponse(empUpdatedResult);
	} 
	
	private ResponseEntity<String> createCustomHeaderResponse(String result){
		 HttpHeaders responseHeaders = new HttpHeaders();
		 responseHeaders.set("employee-Save",result);
		 return ResponseEntity.ok()
		      .headers(responseHeaders)
		      .body(result);
	}
/*	
	private ResponseEntity<String> createCustomHeaderResponse(String result, String requestStatus, Exception e){
		ResponseEntity<String> responseString = null;
		 HttpHeaders responseHeaders = new HttpHeaders();
		 responseHeaders.set("employee-Save",result);
		 if(requestStatus.equals(BAD_REQUEST)){
			 responseString = ResponseEntity.badRequest()
		      .headers(responseHeaders)
		      .body(result);
		 }
		 return responseString;
	}
	*/
	public void setEmployeeService(EmployeeService employeeService) {
		  this.employeeService = employeeService;
	}

	public void setErrorCodeService(ErrorCodeService errorCodeService) {
		this.errorCodeService = errorCodeService;
	}
}

//URL: http://localhost:7001/emsrestxml/save-emp-info
/*
* 
Request: 

<?xml version="1.0" encoding="UTF-8"?>
<employee>
  <id>2221</id>
  <name>Prashanth</name>
  <joiningDate>27/08/2019</joiningDate>
  <department>HR</department>
</employee>

<?xml version="1.0" encoding="utf-8"?>
<employee xsi:noNamespaceSchemaLocation="schema.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <id>A21</id>
  <name>Prashanth</name>
  <joiningDate>27/08/2019</joiningDate>
  <department>HR</department>
</employee>

* 
* 
* */



