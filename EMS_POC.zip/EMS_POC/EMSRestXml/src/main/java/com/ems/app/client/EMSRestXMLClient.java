package com.ems.app.client;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

public class EMSRestXMLClient {
	private static final Logger logger = LoggerFactory.getLogger(EMSRestXMLClient.class);
	private final static int TIMEOUT = (int) TimeUnit.SECONDS.toMillis(30);
	
	/**
	 * Client call to EMS Rest service
	 * @param ars
	 */
	public static void main(String ars[]){
		logger.debug("Start of Main method");
		try {
			//EMSRestXMLClient.getHome();
			EMSRestXMLClient.createEmployee();
			EMSRestXMLClient.updateEmployee();
		} catch (Exception e) {
			logger.error("Exception while calling Rest service from Rest client"+e.getMessage());
		}
		logger.debug("End of Main method");
	}
	
	
	public static void getHome(){
		try{
			final String uri = "http://localhost:7001/emsrestxml";
			RestTemplate restTemplate = new RestTemplate();
			String result = restTemplate.getForObject(uri, String.class);
			System.out.println("result :: "+ result);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	/**
	 * Rest client API call to create Rest service
	 */
	public static void createEmployee(){
	//	http://localhost:7001/emsrestxml/saveempinfo
		String uri = "http://localhost:7001/emsrestxml/saveempinfo";
		try{
			logger.debug("######### Begin Webservice clint :: createEmployee call ######### \n");
			RestTemplate restTemplate =  new RestTemplate();
			SimpleClientHttpRequestFactory factory = (SimpleClientHttpRequestFactory) restTemplate.getRequestFactory();
		    factory.setReadTimeout(TIMEOUT);
		    factory.setConnectTimeout(TIMEOUT);
		
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_XML);
			
			StringBuffer urlParameters = new StringBuffer("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
			urlParameters.append("<employee xsi:noNamespaceSchemaLocation=\"schema.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><id>A2001</id>");
	        urlParameters.append("<name>Rajesh</name><joiningDate>25/08/2019</joiningDate><department>IT</department></employee>");
			
			HttpEntity<String> request = new HttpEntity<String>(urlParameters.toString(), headers);
			ResponseEntity<String> response = restTemplate.postForEntity(uri, request, String.class);
			
			if(response.getStatusCode() == HttpStatus.OK){
				logger.debug("Employee Save was successful :: "+response.getHeaders().getValuesAsList("employee-Save"));
			}
		}catch (HttpClientErrorException | HttpServerErrorException httpClientOrServerExc) {
		    logger.error("Exception while calling the save user service"+httpClientOrServerExc.getMessage());
			httpClientOrServerExc.printStackTrace();
		    if(HttpStatus.NOT_FOUND.equals(httpClientOrServerExc.getStatusCode())) {
		      throw new RuntimeException("Service Not Found : : ", httpClientOrServerExc);
		    } else {
		    	logger.error("Exception in the save user service "+httpClientOrServerExc.getMessage());
		    }
		}catch(Exception e){
			logger.error("Exception occured in the save user service "+e.getMessage());
		}
		logger.debug("## Webservice clint :: createEmployee call End");
	}
	
	/**
	 * Rest client API call to create Rest service
	 */
	public static void updateEmployee(){
		try{
			logger.debug("######### Begin Webservice clint :: updateEmployee call ######### \n");
			RestTemplate restTemplate = new RestTemplate();
	        String url = "http://localhost:7001/emsrestxml/empdata/{id}";
	        
	        StringBuffer urlParameters = new StringBuffer("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
			urlParameters.append("<employee xsi:noNamespaceSchemaLocation=\"schema.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><id>A2001</id>");
	        urlParameters.append("<name>Alvin</name><joiningDate>25/09/2019</joiningDate><department>IT</department></employee>");
	        
	        HttpHeaders headers = new HttpHeaders();
	        headers.setContentType(MediaType.APPLICATION_XML);
	        HttpEntity<String> request = new HttpEntity<String>(urlParameters.toString(), headers);
	        
	        Map<String, String> map = new HashMap<String, String>();
	        map.put("id", "A2001");
	        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.PUT, request, String.class,map);
	        if(response.getStatusCode() == HttpStatus.OK){
				logger.debug("Employee Update was Successful call :: "+response.getHeaders().getValuesAsList("employee-Save"));
			}
		}catch (HttpClientErrorException | HttpServerErrorException httpClientOrServerExc) {
		    logger.error("Exception while calling the save user service"+httpClientOrServerExc.getMessage());
			httpClientOrServerExc.printStackTrace();
		    if(HttpStatus.NOT_FOUND.equals(httpClientOrServerExc.getStatusCode())) {
		      throw new RuntimeException("Service Not Found : : ", httpClientOrServerExc);
		    } else {
		    	logger.error("Exception in the update user :: "+httpClientOrServerExc.getMessage());
		    }
		}catch(Exception e){
			logger.error("Exception occured in the update user : :"+e.getMessage());
		}
		logger.debug("########## Webservice clint :: updateEmployee call End ######### \n");
	}
	
}