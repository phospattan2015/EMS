package com.ems.app.util;

import java.io.File;
import java.io.IOException;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.util.JAXBSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.xml.sax.SAXException;

import com.ems.app.entity.EmployeeEntity;
import com.ems.app.xsd.Employee;

public class EMSRestUtil {

	/**
	 * API will validate input employee request against XSD.
	 * @param employee
	 * @return boolean
	 * @throws JAXBException
	 * @throws SAXException
	 * @throws IOException
	 */
	public static boolean isEmployeeValid(Employee employee) throws JAXBException, SAXException, IOException{
        JAXBContext jc = JAXBContext.newInstance(Employee.class);
        JAXBSource source = new JAXBSource(jc, employee);
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI); 
        Schema schema = sf.newSchema(new File("Employee.xsd")); 
        Validator validator = schema.newValidator();
        validator.setErrorHandler(new MyErrorHandler());
        validator.validate(source);
		return true;
	}

	/**
	 * API will transform Input Employee request to Employee Entity
	 * @param employee
	 * @return EmployeeEntity
	 */
	public static EmployeeEntity tranferDTO(Employee employee) {
		EmployeeEntity empEntity=new EmployeeEntity(employee.getId(), employee.getName(), 
				employee.getJoiningDate(),employee.getDepartment().name());
		return empEntity;
	}
	
	
	public static Employee transformEmployeeDTO(EmployeeEntity employeeEntity){
		Employee employee=new Employee();
		employee.setId(String.valueOf(employeeEntity.getId()));
		employee.setName(employeeEntity.getName());
		employee.setJoiningDate(employeeEntity.getJoiningDate());
		employee.setJoiningDate(employeeEntity.getDepartment());
		return employee;
	}
}
