package com.ems.app.service;

import com.ems.app.entity.ErrorCode;

public interface ErrorCodeService {
	public void insertError(ErrorCode errorCode);
}
