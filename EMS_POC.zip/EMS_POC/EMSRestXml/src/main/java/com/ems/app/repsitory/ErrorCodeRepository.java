package com.ems.app.repsitory;


import org.springframework.data.jpa.repository.JpaRepository;

import com.ems.app.entity.ErrorCode;

public interface ErrorCodeRepository extends JpaRepository<ErrorCode,Long>{

}
