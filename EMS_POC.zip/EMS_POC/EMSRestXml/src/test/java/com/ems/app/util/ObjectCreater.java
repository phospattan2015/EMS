package com.ems.app.util;

import com.ems.app.entity.EmployeeEntity;
import com.ems.app.entity.ErrorCode;
import com.ems.app.xsd.DepartmentTypes;
import com.ems.app.xsd.Employee;

public class ObjectCreater {
	
	public Employee createEmployee(){
		Employee  employee = new Employee();
		employee.setId("20003");
	    employee.setName("Rajesh");
	    employee.setJoiningDate("25/09/19");
	    employee.setDepartment(DepartmentTypes.IT);
	    return employee;
	}
	
	public EmployeeEntity createEmployeeEntity(){
		EmployeeEntity employeeEntity = new EmployeeEntity("A200031", "Rajesh", "25/09/19","IT");
		return employeeEntity;
	}
	
	public ErrorCode createErrorCode(){
		ErrorCode  errorCode = new ErrorCode();
		errorCode.setErrorCode(1000);
		errorCode.setErrrorDescription("Invalid XML");
		errorCode.setId(1001l);
	    return errorCode;
	}

}
