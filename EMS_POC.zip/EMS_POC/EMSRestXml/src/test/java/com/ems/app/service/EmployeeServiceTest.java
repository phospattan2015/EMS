package com.ems.app.service;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;

import java.io.IOException;

import javax.xml.bind.JAXBException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.xml.sax.SAXException;

import com.ems.app.entity.EmployeeEntity;
import com.ems.app.exceptions.InvalidRequestException;
import com.ems.app.repsitory.EmployeeRepository;
import com.ems.app.service.impl.EmployeeServiceImpl;
import com.ems.app.util.EMSRestUtil;
import com.ems.app.util.ObjectCreater;
import com.ems.app.xsd.Employee;

@RunWith(MockitoJUnitRunner.class)
public class EmployeeServiceTest {
	@Mock
	private EmployeeService employeeService;
    
	@Mock
	private EmployeeRepository employeeRepository;
	
	private Employee employee = null;
	private EmployeeEntity  inputEmpEntity=null;
	private EmployeeEntity  savedEmpEntity=null;
	private ObjectCreater objectCreater=null;
 
    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Before
    public void setUpBefore(){
    	MockitoAnnotations.initMocks(this);
    	objectCreater = new ObjectCreater();
	    employee = objectCreater.createEmployee();
	    inputEmpEntity = EMSRestUtil.tranferDTO(employee);
	    savedEmpEntity = EMSRestUtil.tranferDTO(employee);
	    employeeService = new EmployeeServiceImpl(employeeRepository);
    }
	
    @Test
    public void saveEmployeeTest() throws InvalidRequestException{      
        when(employeeRepository.save(inputEmpEntity)).thenReturn(savedEmpEntity);
        //test  save employee
        try {
        	employeeService.saveEmployee(employee);
		} catch (JAXBException | SAXException | IOException e) {
			assertThat(e.getMessage(), is("error"));
		}
        assertNotNull(savedEmpEntity);
    }
    
    @Test
    public void updateEmployeeTest() throws InvalidRequestException{   
    	when(employeeRepository.save(inputEmpEntity)).thenReturn(savedEmpEntity);
    	 //test update employee
        try {
        	employeeService.updateEmployee(employee);
		} catch (JAXBException | SAXException | IOException e) {
			assertThat(e.getMessage(), is("error"));
		}
        assertNotNull(savedEmpEntity);
    }
	
}
