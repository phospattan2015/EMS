package com.ems.app.entity;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.ems.app.util.ObjectCreater;

public class EmployeeEntityTest {

	private EmployeeEntity employeeEntity =null;
	private ObjectCreater objectCreate =null;  
	
	@Before
    public void setUpBefore(){
		objectCreate = new ObjectCreater();
		employeeEntity = objectCreate.createEmployeeEntity();
	}
	
	@Test
	public void testGetter(){
		assertEquals("A200031",employeeEntity.getId()); 
		assertEquals("Rajesh",employeeEntity.getName());
		assertEquals("25/09/19",employeeEntity.getJoiningDate());
		assertEquals("IT",employeeEntity.getDepartment());
	}
}
