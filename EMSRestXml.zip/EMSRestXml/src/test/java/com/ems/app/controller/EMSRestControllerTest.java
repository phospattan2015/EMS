package com.ems.app.controller;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.ems.app.service.EmployeeService;
import com.ems.app.service.ErrorCodeService;
import com.ems.app.xsd.Employee;


@RunWith(SpringRunner.class)
@WebMvcTest(value = EMSRestController.class, secure = false)
public class EMSRestControllerTest {
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private EmployeeService employeeService;
	
	@MockBean
	private ErrorCodeService errorCodeService;
	
    @Before
    public void setUpBefore(){
    	MockitoAnnotations.initMocks(this);
    }
	
	@Test
	public void testSaveEmployeeInfo() throws Exception{

		// employeeService.saveEmployee to respond back with mockBoolean
		Mockito.when(employeeService.saveEmployee(Mockito.any(Employee.class))).thenReturn(true);
		
		
	   StringBuffer urlParameters = new StringBuffer("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
	   urlParameters.append("<employee xsi:noNamespaceSchemaLocation=\"schema.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><id>51</id>");
        urlParameters.append("<name>Rajesh</name><joiningDate>25/08/2019</joiningDate><department>IT</department></employee>");

		// Send course as body to /saveempinfo
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/saveempinfo")
				.accept(MediaType.APPLICATION_XML).content(urlParameters.toString())
				.contentType(MediaType.APPLICATION_XML);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		MockHttpServletResponse response = result.getResponse();
		assertEquals(HttpStatus.OK.value(), response.getStatus());	
	}
	
	
	@Test
	public void testUpdateEmployeeInfo() throws Exception{

		// employeeService.saveEmployee to respond back with mockBoolean
	   Mockito.when(employeeService.updateEmployee(Mockito.any(Employee.class))).thenReturn(true);
		
	   long empId=20003l;
	  
	   StringBuffer urlParameters = new StringBuffer("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
	   urlParameters.append("<employee xsi:noNamespaceSchemaLocation=\"schema.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><id>51</id>");
       urlParameters.append("<name>Rajesh</name><joiningDate>25/08/2019</joiningDate><department>IT</department></employee>");

		// Send employee as body to /update employee
		RequestBuilder requestBuilder = MockMvcRequestBuilders
				.put("/empdata/"+empId)
				.accept(MediaType.APPLICATION_XML).content(urlParameters.toString())
				.contentType(MediaType.APPLICATION_XML);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();

		MockHttpServletResponse response = result.getResponse();
		assertEquals(HttpStatus.OK.value(), response.getStatus());	
		System.out.println("Response "+response.getContentAsString());
	}
}
