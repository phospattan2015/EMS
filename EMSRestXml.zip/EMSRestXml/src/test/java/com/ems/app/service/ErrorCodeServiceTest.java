package com.ems.app.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.ems.app.entity.ErrorCode;
import com.ems.app.repsitory.ErrorCodeRepository;
import com.ems.app.service.impl.ErrorCodeServiceImpl;
import com.ems.app.util.ObjectCreater;

@RunWith(MockitoJUnitRunner.class)
public class ErrorCodeServiceTest {

	@Mock
	private ErrorCodeService errorCodeService;
    
	@Mock
	private ErrorCodeRepository errorCodeRepository;
	
	private ErrorCode inputErrorCode = null;
	private ErrorCode savedErrorCode = null;
	private ObjectCreater objectCreater=null;
 
    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Before
    public void setUpBefore(){
    	MockitoAnnotations.initMocks(this);
    	objectCreater = new ObjectCreater();
    	inputErrorCode = objectCreater.createErrorCode();
    	savedErrorCode = objectCreater.createErrorCode();
    	errorCodeService = new ErrorCodeServiceImpl(errorCodeRepository);
    }
    
    @Test
    public void testInsertErrorCode(){
    	 when(errorCodeRepository.save(inputErrorCode)).thenReturn(savedErrorCode);
    	 errorCodeService.insertError(inputErrorCode);
    	 assertNotNull(savedErrorCode);
    }
	
}
