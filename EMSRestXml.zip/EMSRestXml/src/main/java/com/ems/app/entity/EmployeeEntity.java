package com.ems.app.entity;
import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

@Entity
@Table(name="tbl_employee")
public class EmployeeEntity implements Serializable{
	 
	private static final long serialVersionUID = -2884446154777060900L;

	 @Id
	 @Column(name="id")
	 private String id;
	  
	 @Column(name="EMPLOYEE_NAME")
	 private String name;
	  
	 @Column(name="JOINING_DATE")
	 private String joiningDate;
	  
	 @Column(name="DEPARTMENT")
	 private String department;
	 
	 @Column(name = "CREATED_DATE", insertable = true, updatable = false)
	 private Timestamp createdDate;
	 
	 @Column(name = "UPDATED_DATE", insertable = true, updatable = true)
	 private Timestamp updatedDate;
	 
	 public EmployeeEntity(){
		 
	 }
	 
	public EmployeeEntity(String id, String name, String joiningDate,String department){
		this.id=id;
		this.name=name;
		this.joiningDate =joiningDate;
		this.department=department;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(String joiningDate) {
		this.joiningDate = joiningDate;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public Timestamp getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Timestamp createdDate) {
		this.createdDate = createdDate;
	}

	public Timestamp getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Timestamp updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	@PrePersist
	void onCreate() {
		this.setCreatedDate(new Timestamp((new java.util.Date()).getTime()));
	}

	@PreUpdate
	void onPersist() {
		this.setUpdatedDate(new Timestamp((new java.util.Date()).getTime()));
	}
}