package com.ems.app.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ems.app.entity.ErrorCode;
import com.ems.app.repsitory.ErrorCodeRepository;
import com.ems.app.service.ErrorCodeService;

@Service
public class ErrorCodeServiceImpl implements ErrorCodeService{

	 @Autowired
	 private ErrorCodeRepository errorCodeRepository;
	 
	 public ErrorCodeServiceImpl(ErrorCodeRepository errorCodeRepository){
		 this.errorCodeRepository = errorCodeRepository;
	 }
	 
	@Override
	public void insertError(ErrorCode errorCode) {
		errorCodeRepository.save(errorCode);
	}
}
