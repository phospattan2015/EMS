package com.ems.app.service.impl;

import java.io.IOException;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

import com.ems.app.entity.EmployeeEntity;
import com.ems.app.repsitory.EmployeeRepository;
import com.ems.app.service.EmployeeService;
import com.ems.app.util.EMSRestUtil;
import com.ems.app.xsd.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	private static final Logger logger = LoggerFactory.getLogger(EmployeeServiceImpl.class);
	private EmployeeRepository employeeRepository;
	 
	 @Autowired
	 public EmployeeServiceImpl(EmployeeRepository employeeRepository){
		 this.employeeRepository = employeeRepository;
	 }
	 
	 /**
	  *  API will persist the provided employee
	  */
	 public boolean saveEmployee(Employee employee) throws JAXBException, SAXException, IOException{
		 validateEmployee(employee);
	     employeeRepository.save(EMSRestUtil.tranferDTO(employee));
	     return true;
	 }
	 
	 /**
	  * API will update the provided employee
	  */
	 public boolean updateEmployee(Employee employee) throws JAXBException, SAXException, IOException {
		validateEmployee(employee);
		employeeRepository.save(EMSRestUtil.tranferDTO(employee));
		return true;
	 }
	 
	 /**
	  * API will validate employee using XSD
	  * @param employee
	  * @throws JAXBException
	  * @throws SAXException
	  * @throws IOException
	  */
	 private void validateEmployee(Employee employee) throws JAXBException, SAXException, IOException{
		 logger.info("XSD validationss start here!");
		 long startTime = System.currentTimeMillis(); 
		 EMSRestUtil.isEmployeeValid(employee);
		 long end = System.currentTimeMillis(); 
	  	 long timeElaspe =end - startTime; 
	     logger.debug("Time Taken to validate an input XML in milli seconds :"+timeElaspe);
	 }
	 
	 
}
