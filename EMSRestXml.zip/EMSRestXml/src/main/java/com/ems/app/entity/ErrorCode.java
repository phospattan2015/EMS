package com.ems.app.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ERROR_CODE")
public class ErrorCode implements Serializable{
	
	private static final long serialVersionUID = 2525039531153393549L;

	@Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
	
	@Column(name="ERROR_CODE")
	private int errorCode;
	
	@Column(name="ERROR_DESCRIPTION")
	private String errrorDescription;
	
	public ErrorCode(){
		
	}

	public ErrorCode(int errorCode, String errorDescription) {
		this.errorCode=errorCode;
		this.errrorDescription=errorDescription;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrrorDescription() {
		return errrorDescription;
	}

	public void setErrrorDescription(String errrorDescription) {
		this.errrorDescription = errrorDescription;
	}
}
