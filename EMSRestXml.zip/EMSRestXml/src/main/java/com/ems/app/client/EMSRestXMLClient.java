package com.ems.app.client;


import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

public class EMSRestXMLClient {
	private static final Logger logger = LoggerFactory.getLogger(EMSRestXMLClient.class);
	private final static int TIMEOUT = (int) TimeUnit.SECONDS.toMillis(30);
	
	/**
	 * Client call to EMS Rest service
	 * @param ars
	 */
	public static void main(String ars[]){
		logger.debug("Start of Main method");
		try {
			//EMSRestXMLClient.getHome();
			
			EMSRestXMLClient.createEmployee();
			
			EMSRestXMLClient.updateEmployee();
			
			
			
		//	EMSRestXMLClient.createEmp();
				
		} catch (Exception e) {
			logger.error("Exception while calling Rest service from Rest client"+e.getMessage());
		}
		logger.debug("End of Main method");
	}
	
	
	public static void getHome(){
		try{
			final String uri = "http://localhost:7001/emsrestxml";
			RestTemplate restTemplate = new RestTemplate();
			String result = restTemplate.getForObject(uri, String.class);
			System.out.println("result :: "+ result);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	/**
	 * Rest client API call to create Rest service
	 */
	public static void createEmployee(){
	//	http://localhost:7001/emsrestxml/saveempinfo
		String uri = "http://localhost:7001/emsrestxml/saveempinfo";
		try{
			logger.debug("######### Begin Webservice clint :: createEmployee call ######### \n");
			RestTemplate restTemplate =  new RestTemplate();
			SimpleClientHttpRequestFactory factory = (SimpleClientHttpRequestFactory) restTemplate.getRequestFactory();
		    factory.setReadTimeout(TIMEOUT);
		    factory.setConnectTimeout(TIMEOUT);
		
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_XML);
			
			StringBuffer urlParameters = new StringBuffer("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
			urlParameters.append("<employee xsi:noNamespaceSchemaLocation=\"schema.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><id>A2001</id>");
	        urlParameters.append("<name>Rajesh</name><joiningDate>25/08/2019</joiningDate><department>IT</department></employee>");
			
			HttpEntity<String> request = new HttpEntity<String>(urlParameters.toString(), headers);
			ResponseEntity<String> response = restTemplate.postForEntity(uri, request, String.class);
			
			if(response.getStatusCode() == HttpStatus.OK){
				logger.debug("Successful call");
			}
			
			logger.debug("Status Code "+response.getStatusCode());
		}catch (HttpClientErrorException | HttpServerErrorException httpClientOrServerExc) {
		    logger.error("Exception while calling the save user service"+httpClientOrServerExc.getMessage());
			httpClientOrServerExc.printStackTrace();
		    if(HttpStatus.NOT_FOUND.equals(httpClientOrServerExc.getStatusCode())) {
		      throw new RuntimeException("Service Not Found : : ", httpClientOrServerExc);
		    } else {
		      // your handling of other errors here
		    	logger.error("Exception in the save user service "+httpClientOrServerExc.getMessage());
		    }
		}catch(Exception e){
			logger.error("Exception occured in the save user service "+e.getMessage());
		}
		logger.debug("## Webservice clint :: createEmployee call End");
	}
	
	/**
	 * Rest client API call to create Rest service
	 */
	public static void updateEmployee(){
		try{
			logger.debug("######### Begin Webservice clint :: updateEmployee call ######### \n");
			RestTemplate restTemplate = new RestTemplate();
	        String url = "http://localhost:7001/emsrestxml/empdata/{id}";
	        
	        StringBuffer urlParameters = new StringBuffer("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
			urlParameters.append("<employee xsi:noNamespaceSchemaLocation=\"schema.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><id>A2001</id>");
	        urlParameters.append("<name>Alvin</name><joiningDate>25/09/2019</joiningDate><department>IT</department></employee>");
	        
	        HttpHeaders headers = new HttpHeaders();
	        headers.setContentType(MediaType.APPLICATION_XML);
	        HttpEntity<String> request = new HttpEntity<String>(urlParameters.toString(), headers);
	        
	        Map<String, String> map = new HashMap<String, String>();
	        map.put("id", "A2001");
	        restTemplate.put(url, request, map);
	        logger.debug("end");
		}catch (HttpClientErrorException | HttpServerErrorException httpClientOrServerExc) {
		    logger.error("Exception while calling the save user service"+httpClientOrServerExc.getMessage());
			httpClientOrServerExc.printStackTrace();
		    if(HttpStatus.NOT_FOUND.equals(httpClientOrServerExc.getStatusCode())) {
		      throw new RuntimeException("Service Not Found : : ", httpClientOrServerExc);
		    } else {
		      // your handling of other errors here
		    	logger.error("Exception in the update user :: "+httpClientOrServerExc.getMessage());
		    }
		}catch(Exception e){
			logger.error("Exception occured in the update user : :"+e.getMessage());
		}
		logger.debug("########## Webservice clint :: updateEmployee call End ######### \n");
	}
	
	
	/**
	 * Web service Rest client create employee call to EMS Rest service. 
	 */
	/*
	private static  void createEmp(){
	    logger.debug("Inside client create Employee");
		String uri = "http://localhost:8080/ems-rest-xml/save-emp-info";
		URL obj = null;
		HttpURLConnection con = null;
		try {
            obj = new URL(uri);
            con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type",
                    "application/xml;charset=utf-8");

            StringBuffer urlParameters = new StringBuffer("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
            urlParameters.append("<employee xsi:noNamespaceSchemaLocation=\"schema.xsd\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><id>A21</id>");
            urlParameters.append("<name>Rajesh</name><joiningDate>13/08/2019</joiningDate><department>HR</department></employee>");

            con.setDoOutput(true);
            DataOutputStream wr = new DataOutputStream(con.getOutputStream());
            wr.writeBytes(urlParameters.toString());
            wr.flush();
            wr.close();
            String responseStatus = con.getResponseMessage();
            
            logger.debug("Ressponse status"+responseStatus);
            
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            logger.debug("response:" + response.toString());            
        }catch (IOException e) {
        	logger.error("IO Exception while calling Rest service from Rest client"+e.getLocalizedMessage());
        }catch(Exception e){
        	logger.error("Exception while calling Rest service from Rest client"+e.getLocalizedMessage());
        }
		logger.debug("Reached end of the create emp inside the rest client!");
	}
	*/
}
