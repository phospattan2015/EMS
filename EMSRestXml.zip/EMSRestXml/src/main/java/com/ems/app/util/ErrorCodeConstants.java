package com.ems.app.util;

public interface ErrorCodeConstants {
	
	//ERROR Codes
	int ERROR_CODE_1001 = 1001;
	int ERROR_CODE_2001 = 2001;
	
	
	// Error Description
	//XML errors
	String INVALID_XML_INPUT ="Invalid Xml input";
	
	//JPA or database errors
	String JPA_CREATE_USER_ERRROR ="JPA create user Error";
	
	

}
